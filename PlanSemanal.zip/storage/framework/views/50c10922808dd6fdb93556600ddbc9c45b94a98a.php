


<?php $__env->startSection('title', 'Agregar Actividades'); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .colorTop { 
            background-color: #541533;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">REGISTRO DE ACTIVIDADES</div>
            <div class="card-body">
                <div class="row">
                    <div class="col-3">Órgano Administrativo</div>
                    <div class="col-4">
                        <select name="organo" class="form-control" id="organo">
                            <option value="<?php echo e($organos[0]->id); ?>"><?php echo e($organos[0]->descripcion); ?></option>
                        </select>
                    </div>
                </div>

                <form id="formSearch" action="<?php echo e(route('actividades.inicio')); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <div class="row my-2">
                        <div class="col-3">Ejercicio</div>
                        <div class="col-4">
                            <select class="custom-select" id="ejercicio" name="ejercicio">
                                
                                <option <?php echo e($ejercicio == '2021' ? 'selected' : ''); ?>>2021</option>
                                <option <?php echo e(($ejercicio == '2022' || $ejercicio == null) ? 'selected' : ''); ?>>2022</option>
                                <option <?php echo e($ejercicio == '2023' ? 'selected' : ''); ?>>2023</option>
                                <option <?php echo e($ejercicio == '2024' ? 'selected' : ''); ?>>2024</option>
                                <option <?php echo e($ejercicio == '2025' ? 'selected' : ''); ?>>2025</option>
                                <option <?php echo e($ejercicio == '2026' ? 'selected' : ''); ?>>2026</option>
                                <option <?php echo e($ejercicio == '2027' ? 'selected' : ''); ?>>2027</option>
                                <option <?php echo e($ejercicio == '2028' ? 'selected' : ''); ?>>2028</option>
                                <option <?php echo e($ejercicio == '2029' ? 'selected' : ''); ?>>2029</option>
                                <option <?php echo e($ejercicio == '2030' ? 'selected' : ''); ?>>2030</option>
                            </select>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-3">Semana</div>
                        <div class="col-4">
                            <input class="form-control" type="number" name="busqueda" id="busqueda"
                            placeholder="Semana" value="<?php echo e($semana); ?>">
                        </div>
                        <div class="col">
                            <button type="submit" id="btnBuscarCurso" class="btn btn-primary">FILTRAR</button>
                        </div>
                    </div>
                </form>

                <hr class="my-4">
                <form id="formAddActivity" action="<?php echo e(route('actividades.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <div class="row d-flex align-items-center">
                        <div class="form-group col">
                            <label for="fecha" class="control-label">Fecha</label>
                            <input type='text' id="fecha" autocomplete="off" readonly="readonly" name="fecha"
                                class="form-control datepicker" required>
                        </div>

                        <div class="form-group col">
                            <label for="asunto" class="control-label">Asunto</label>
                            <textarea name="asunto" id="asunto" class="form-control" placeholder="Asunto" cols="30" rows="2"></textarea>
                        </div>

                        

                        <div class="form-group col">
                            <label for="actividad" class="control-label">Actividad</label>
                            <textarea name="actividad" id="actividad" class="form-control" placeholder="Actividad" cols="30" rows="2"></textarea>
                        </div>

                        <div class="form-group col">
                            <label for="observaciones" class="control-label">Observaciones</label>
                            <textarea class="form-control" name="observaciones" id="observaciones" cols="30" rows="2" placeholder="Observaciones"></textarea>
                        </div>

                        <div class="form-group col">
                            <label for="semana" class="control-label">Semana</label>
                            <input type="number" class="form-control" id="semana" name="semana" placeholder="Semana"
                                value="<?php echo e($semana); ?>">
                        </div>

                        <div class="form-group col">
                            <label for="status" class="control-label">Estado</label>
                            <select name="status" class="form-control" id="status">
                                <option value="">Seleccione</option>
                                <option value="INICIADO">INICIADO</option>
                                <option value="EN PROCESO">EN PROCESO</option>
                                <option value="TERMINADO">TERMINADO</option>
                            </select>
                        </div>

                        <div class="form-group col">
                            <label for="tipo_actividad" class="control-label">Tipo de actividad</label>
                            <select name="tipo_actividad" class="form-control" id="tipo_actividad">
                                <option value="">Seleccione</option>
                                <option value="ACTIVIDAD">ACTIVIDAD</option>
                                <option value="PERMISO">PERMISO</option>
                            </select>
                        </div>

                        <div class="form-group col-1 mt-2">
                            <button type="submit" class="btn btn-primary">Agregar</button>
                        </div>
                    </div>
                </form>

                <hr>
                <div class="row">
                    <?php if(!$actividades->isEmpty()): ?>
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">Fecha</th>
                                    <th scope="col">Asunto</th>
                                    <th scope="col">Área responsable</th>
                                    <th scope="col">Actividad</th>
                                    <th scope="col">Estatus</th>
                                    <th scope="col">Observaciones</th>
                                    <th scope="col">Tipo</th>
                                    <th scope="col">Semana</th>
                                    <th scope="col">Enviado</th>
                                    <th scope="col">Opción</th>
                                    <?php if($showModify == 'true'): ?>
                                        <th scope="col">Indicaciones DG</th>
                                    <?php endif; ?>
                                    <?php if($showModify == 'true'): ?>
                                        <th scope="col">Modificar</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <form id="formStatus_<?php echo e($actividad->id); ?>"
                                            action="<?php echo e(route('actividades.editar', ['id' => $actividad->id, 'semana'=>$actividad->semana])); ?>" method="post">
                                            <?php echo csrf_field(); ?>

                                            <td width="100px"><?php echo e($actividad->fecha); ?></td>
                                            <td><?php echo e($actividad->asunto); ?></td>
                                            <td><?php echo e($actividad->descripcion); ?></td>
                                            <td><?php echo e($actividad->actividad); ?></td>
                                            <td width="170px">
                                                <select name="<?php echo e($actividad->id); ?>" id="<?php echo e($actividad->id); ?>"
                                                    class="form-control">
                                                    <option <?php echo e($actividad->status == 'INICIADO' ? 'selected' : ''); ?>

                                                        value="INICIADO">INICIADO</option>
                                                    <option <?php echo e($actividad->status == 'EN PROCESO' ? 'selected' : ''); ?>

                                                        value="EN PROCESO">EN PROCESO</option>
                                                    <option <?php echo e($actividad->status == 'TERMINADO' ? 'selected' : ''); ?>

                                                        value="TERMINADO">TERMINADO</option>
                                                </select>
                                            </td>
                                            <td><?php echo e($actividad->observaciones); ?></td>
                                            <td width="100px" ><?php echo e($actividad->tipo_actividad); ?></td>
                                            <td width="40px"><?php echo e($actividad->semana); ?></td>
                                            <td width="40px">
                                                <?php if($actividad->fecha_enviado == null): ?>
                                                    NO
                                                <?php else: ?>
                                                    SI
                                                <?php endif; ?>
                                            </td>
                                            <td width="120px">
                                                <?php if($actividad->fecha_enviado == null): ?>
                                                    <div class="row d-flex justify-content-center">
                                                        <?php if($showModify != 'true'): ?>
                                                            <a class="btn btn-info btn-circle m-1 btn-circle-sm" title="Modificar Status"
                                                                href="#"
                                                                onclick="document.getElementById('formStatus_' + <?php echo e($actividad->id); ?>).submit()">
                                                                <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                                            </a>
                                                        <?php endif; ?>

                                                        <a class="btn btn-danger btn-circle m-1 btn-circle-sm" title="Eliminar"
                                                            href="<?php echo e(route('actividades.destroy', ['id'=>$actividad->id, 'semana'=>$actividad->semana])); ?>">
                                                            <i class="fa fa-trash" aria-hidden="true"></i>
                                                        </a>
                                                    </div>
                                                <?php else: ?>
                                                    NO DISPONIBLE
                                                <?php endif; ?>
                                            </td>

                                            <?php if($showModify == 'true'): ?>
                                                <td width="140px">
                                                    <?php if($actividad->mostrar != null): ?>
                                                        <?php if( str_contains($actividad->mostrar, 'Director')): ?>
                                                            <?php echo e($actividad->ind_direccion); ?>

                                                        <?php else: ?>
                                                            <small>Permiso no otorgado</small>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <?php echo e($actividad->ind_direccion); ?>

                                                    <?php endif; ?>
                                                    
                                                </td>
                                            <?php endif; ?>
                                        
                                            <?php if($showModify == 'true' && $show == 'true'): ?>
                                                <td>
                                                    <button onclick="showModal(<?php echo e($actividad); ?>)" type="button" class="btn btn-success btn-sm" 
                                                        data-toggle="modal" data-target="#modalModify">Modificar</button>
                                                </td>
                                            <?php else: ?>
                                                <?php if($showModify != 'false'): ?>
                                                    <td>
                                                        <?php if($actividad->fecha_vToBueno == null): ?>
                                                            <button onclick="showModal(<?php echo e($actividad); ?>)" type="button" class="btn btn-success btn-sm" 
                                                                data-toggle="modal" data-target="#modalModify">Modificar</button>
                                                        <?php elseif($actividad->mostrar != null && str_contains($actividad->mostrar, 'Director')): ?>
                                                            <button onclick="showModal(<?php echo e($actividad); ?>)" type="button" class="btn btn-success btn-sm" 
                                                            data-toggle="modal" data-target="#modalModify">Modificar</button>
                                                        <?php else: ?>
                                                            No Disponible
                                                        <?php endif; ?>
                                                    </td>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </form>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                    <div class="col text-center">
                        <h5><strong>Sin Actividades Registradas</strong></h5>
                    </div>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>

        <?php if(!$actividades->isEmpty()): ?>
            <div class="row my-2">
                <div class="col d-flex justify-content-end">
                    
                    <a class="btn btn-primary btn-lg" title="Enviar" href="<?php echo e(route('actividades.enviar')); ?>">
                        Enviar
                    </a>
                    
                </div>
            </div>
        <?php endif; ?>

        <!-- Modal solicitar semana -->
        <div class="modal fade" id="modalSemana" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <form id="formSemana" enctype="multipart/form-data" action="<?php echo e(route('actividades.enviar')); ?>"
                        method="post">
                        <?php echo csrf_field(); ?>

                        <div class="modal-header bg-primary text-white">
                            <h5 class="modal-title">SEMANA A ENVIAR</h5>
                            <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>

                        <div class="modal-body">
                            
                            
                            <div class="form-group col">
                                <label for="semanaE">NÚMERO DE SEMANA A ENVIAR</label>
                                <input type="number" class="form-control" id="semanaE" name="semanaE" placeholder="Semana">
                            </div>
                        </div>

                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">ENVIAR ACTIVIDADES</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        
        <div id="modalModify" class="modal fade" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    
                    <form action="<?php echo e(route('actividades.editar2')); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Modificación de actividad</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <input class="d-none" type="text" id="id" name="id">
                            <div class="form-group col">
                                <label for="fechaD" class="control-label">Fecha</label>
                                <input type='text' id="fechaD" autocomplete="off" readonly="readonly" name="fechaD"
                                class="form-control datepicker" required>
                            </div>
                            <div class="form-group col">
                                <label for="asuntoD" class="control-label">Asunto</label>
                                <textarea name="asuntoD" id="asuntoD" class="form-control" placeholder="Asunto" cols="30" rows="2"></textarea>
                            </div>
                            <div class="form-group col">
                                <label for="actividadD" class="control-label">Actividad</label>
                                <textarea name="actividadD" id="actividadD" class="form-control" placeholder="Actividad" cols="30" rows="2"></textarea>
                            </div>
                            <div class="form-group col">
                                <label for="observacionesD" class="control-label">Observaciones</label>
                                <textarea class="form-control" name="observacionesD" id="observacionesD" cols="30" rows="2" placeholder="Observaciones"></textarea>
                            </div>
                            <div class="form-group col">
                                <label for="semanaD" class="control-label">Semana</label>
                                <input type="number" class="form-control" id="semanaD" name="semanaD" placeholder="Semana">
                            </div>
                            <div class="form-group col">
                                <label for="statusD" class="control-label">Estado</label>
                                <select name="statusD" class="form-control" id="statusD">
                                    <option value="INICIADO">INICIADO</option>
                                    <option value="EN PROCESO">EN PROCESO</option>
                                    <option value="TERMINADO">TERMINADO</option>
                                </select>
                            </div>

                            <div class="form-group col">
                                <label for="tipo_actividadD" class="control-label">Tipo de actividad</label>
                                <select name="tipo_actividadD" class="form-control" id="tipo_actividadD">
                                    <option value="ACTIVIDAD">ACTIVIDAD</option>
                                    <option value="PERMISO">PERMISO</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-primary">Modificar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>
        $("#fecha").datepicker({
            language: "es",
            defaultDate: "+1w",
            changeMonth: true,
            numberOfMonths: 1,
            dateFormat: 'yy-mm-dd'
        });

        $("#fechaD").datepicker({
            language: "es",
            defaultDate: "+1w",
            changeMonth: true,
            numberOfMonths: 1,
            dateFormat: 'yy-mm-dd'
        });

        $('#formAddActivity').validate({
            rules: {
                fecha: {
                    required: true
                },
                asunto: {
                    required: true
                },
                area_responsable: {
                    required: true
                },
                actividad: {
                    required: true
                },
                status: {
                    required: true
                },
                observaciones: {
                    required: true
                },
                semana: {
                    required: true
                },
                tipo_actividad: {
                    required: true
                }
            },
            messages: {
                fecha: {
                    required: 'Campo requerido'
                },
                asunto: {
                    required: 'Campo requerido'
                },
                area_responsable: {
                    required: 'Campo requerido'
                },
                actividad: {
                    required: 'Campo requerido'
                },
                status: {
                    required: 'Campo requerido'
                },
                observaciones: {
                    required: 'Campo requerido'
                },
                semana: {
                    required: 'Campo requerido'
                },
                tipo_actividad: {
                    required: 'Campo requerido'
                }
            }
        });

        $('#formSemana').validate({
            rules: {
                semanaE: {
                    required: true
                }
            },
            messages: {
                semanaE: {
                    required: 'Debe ingresar el número de semana a enviar'
                }
            }
        });

        function showModal(actividad) {
            $('#id').val(actividad['id']);
            $('#fechaD').val(actividad['fecha']);
            $('#asuntoD').val(actividad['asunto']);
            $('#actividadD').val(actividad['actividad']);
            $('#observacionesD').val(actividad['observaciones']);
            $('#semanaD').val(actividad['semana']);
            $('#statusD').val(actividad['status']);
            $('#tipo_actividadD').val(actividad['tipo_actividad']);
        }

        $('#formSearch').validate({
            rules: {
                ejercicio: { required: true },
                busqueda: { required: true }
            },
            messages: {
                ejercicio: { required: 'Debe seleccionar el ejercicio' },
                busqueda: { required: 'Campo requerido' }
            }
        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlanSemanal\resources\views/layouts/inicioActividades.blade.php ENDPATH**/ ?>